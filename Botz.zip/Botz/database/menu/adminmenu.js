const adminmenu = (prefix) => { 
	return `
╭┤GRUP│
├ 
╰────────────────────╯`
}
exports.adminmenu = adminmenu