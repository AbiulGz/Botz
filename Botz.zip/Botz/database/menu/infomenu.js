const infomenu = (prefix) => { 
	return `
╭┤INFO BOT│
├
╰────────────────────╯`
}
exports.infomenu = infomenu