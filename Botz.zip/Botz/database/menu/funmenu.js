const funmenu = (prefix) => { 
	return `
╭┤FUN│
├ 
╰────────────────────╯`
}
exports.funmenu = funmenu