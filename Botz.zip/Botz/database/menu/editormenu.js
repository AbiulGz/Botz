const editormenu = (prefix) => { 
	return `
╭┤EDITOR│
├ 
╰────────────────────╯`
}
exports.editormenu = editormenu