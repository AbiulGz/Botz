const animemenu = (prefix) => { 
	return `
╭┤ANIME│
├ 
╰────────────────────╯`
}
exports.animemenu = animemenu