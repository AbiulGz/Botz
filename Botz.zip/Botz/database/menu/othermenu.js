const othermenu = (prefix) => { 
	return `
╭┤OTHER│
├ 
╰────────────────────╯`
}
exports.othermenu = othermenu