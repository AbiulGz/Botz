const listmenu = (prefix) => { 
	return `         
╭┤ABOUT BOT│
├ *@verify*
├ *${prefix}snk*
├ *${prefix}limit*
├ *${prefix}level*
├ *${prefix}duit*
├ *${prefix}rules*
├ *${prefix}daftarvip
├ *${prefix}yukigroup*
├ *${prefix}buylimit*
├ *${prefix}yukipay*
├ *${prefix}transfer*
├ *${prefix}lbsaldo*
├ *${prefix}leaderboard*
╰────────────────────╯

╭┤MEDIA│
├ 
╰────────────────────╯

╭┤FUN│
├ *${prefix}memeindo*
├ *${prefix}darkjokes2*
╰────────────────────╯

╭┤MAKER│
├ *${prefix}jail*
├ *${prefix}gaminglogo [TEXT]*
╰────────────────────╯

╭┤ANIME│
├ *${prefix}genreanime*
├ *${prefix}animesaran2*
├ *${prefix}nekopoi*
╰────────────────────╯

╭┤SEARCH│
├ *${prefix}next[FIND PATNER]*
├ *${prefix}mutual[FIND PATNER]*
├ *${prefix}ytsearch [Query]
╰────────────────────╯

╭┤PRAY│
├ 
╰────────────────────╯

╭┤EDITOR│
├ *${prefix}blur*
├ *${prefix}negativegreen*
├ *${prefix}hapusaudio*
├ *${prefix}glitchrgb*
╰────────────────────╯

╭┤SOUND│
├ *${prefix}bass*
├ *${prefix}vibra*
├ *${prefix}earrape*
├ *${prefix}tscowok*
├ *${prefix}nightcore*
╰────────────────────╯

╭┤STICKER│
├ 
╰────────────────────╯

╭┤DOWNLOAD│
├ *${prefix}modapk*
╰────────────────────╯

╭┤KERANG│
├ 
╰────────────────────╯

╭┤GRUP│
├ *${prefix}leveling [on|off]*
╰────────────────────╯

╭┤OWNER│
├ *${prefix}resetlimit*
╰────────────────────╯

╭┤NSFW│
├ *${prefix}kodenuklir*
├ *${prefix}kodenuklir2*
╰────────────────────╯

╭┤PREMIUM│
├ 
╰────────────────────╯

╭┤OTHER│
├ *${prefix}hurufjepang*
├ *${prefix}kamusjepang*
├ *${prefix}bahasalist*
├ *${prefix}readmore [text|text]*
├ *${prefix}modapk*
├ *${prefix}listsay*
╰────────────────────╯

╭┤BIG THANKS FAMILY GAY│
├ *> RECODERS AREA TEAM*
├ *> Alphaking*
├ *> Akbar*
├ *> CALIPH*
├ *> Rizky*
├ *> MhankBarBar*
├ *> DLL*
╰────────────────────╯`
}
exports.listmenu = listmenu