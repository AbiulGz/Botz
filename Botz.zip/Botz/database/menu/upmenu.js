const newvitur = (prefix) => { 
	return `
╭┤UPDATE│
├ 
╰────────────────────╯`
}
exports.newvitur = newvitur