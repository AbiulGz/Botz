const kerangmenu = (prefix) => { 
	return `
╭┤KERANG│
├ 
╰────────────────────╯`
}
exports.kerangmenu = kerangmenu