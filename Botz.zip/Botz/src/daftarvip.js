const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 10K > Akses Fitur ViP
-Rp. 15K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/6283125445725 atau ketik *${prefix}owner*

*NOTE*

*GRUP WHATSAPP BOT :*
_https://chat.whatsapp.com/IKQlIYa7cyJ2wg9i7x068M `
}
exports.daftarvip = daftarvip