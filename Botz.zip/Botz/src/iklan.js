const iklan = () => { 
	return `           
*╭┤IKLAN│*
├ NYATANYA SPRITE NYEGERIN
├ LARUTAN CAP KAKI MAMAH HALAL
├ OSKADON SP REDAKAN PEGAL LINU
│
*├┤PROMOSI│*
├ MINECRAFT ORI
├ Rp20.000
├ DETAIL LENGKAP :
├ https://www.facebook.com/flywings01
│
*├ ALAT PENAMBAH FOLLOWER*
├ (Atur Follower sesuka hati) *PROMO*
├ ~Rp250.000~ - *Rp25.000*
├ FOLLOWER IG
├ Rp1000 - Rp500.000
├ DETAIL LENGKAP :
├ wa.me/+6287764332816
│
*├┤SEWA BOT│*
├ 10K/Grup (bulan)
├ Jadi Admin BOT
├ Dapat menggunakan fitur group
│
*├┤BUAT BOT│*
├ 30K (Full Akses)
├ Costum Nama,Owner,Admin,dll
├ Jadi Owner BOT
├ Unlock All Fitur
├ Bebas menambahkan bot ke grup manapun
├ Dapat Menyewakan BOT ke orang lain
├ +premium dll
│
*├┤PREMIUM/VIP│*
├ 10K/bulan
├ Unlock all fitur Premium
├ Asupan,play,joox dll
├ Unlimited limit
├ dll
│
├ PEMBAYARAN VIA
├ PULSA, DANA
├ HUB wa.me/+6283125445725
├ SEWA + PREMIUM ~20K~ - *15K*
╰────────────────────╯
`
}
exports.iklan = iklan